You can replace the django templates (html files) for the website
here. 

You can find the original files under `evennia/web/templates/website/`. Just 
copy a template here and modify to have it override the default.
